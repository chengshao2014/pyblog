CREATE TABLE `btm_ad` (
  `ad_place` varchar(15) NOT NULL default '',
  `ad_code` text NOT NULL,
  `is_pause` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`ad_place`)
) TYPE=MyISAM;
CREATE TABLE `btm_announce` (
  `announce_id` int(10) unsigned NOT NULL auto_increment,
  `manager_id` smallint(6) unsigned NOT NULL default '0',
  `announce_title` varchar(255) NOT NULL default '',
  `announce_url` varchar(255) NOT NULL default '',
  `announce_content` text NOT NULL,
  `announce_date` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`announce_id`)
) TYPE=MyISAM;
CREATE TABLE `btm_badword` (
  `badword_id` int(10) unsigned NOT NULL auto_increment,
  `badword_name` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`badword_id`),
  UNIQUE KEY `badword_name` (`badword_name`)
) TYPE=MyISAM;
CREATE TABLE `btm_bt_data` (
  `bt_data_id` int(10) unsigned NOT NULL auto_increment,
  `info_hash` blob NOT NULL,
  `hash_id` varchar(40) NOT NULL default '',
  `team_id` int(10) unsigned NOT NULL default '0',
  `node_id` smallint(6) unsigned NOT NULL default '0',
  `user_id` int(10) unsigned NOT NULL default '0',
  `user_name` varchar(50) NOT NULL default '',
  `sort_id` int(10) unsigned NOT NULL default '0',
  `title_style` varchar(15) NOT NULL default '',
  `bt_data_title` varchar(200) NOT NULL default '',
  `bt_data_discuss_url` varchar(255) default NULL,
  `bt_data_file_size` varchar(20) NOT NULL default '',
  `is_local` tinyint(1) NOT NULL default '0',
  `release_date` int(10) unsigned NOT NULL default '0',
  `upgrade_date` int(10) unsigned NOT NULL default '0',
  `ipaddress` varchar(15) NOT NULL default '',
  `is_reseed` tinyint(1) NOT NULL default '0',
  `is_commend` tinyint(1) NOT NULL default '0',
  `put_top` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`bt_data_id`),
  UNIQUE KEY `info_hash` (`info_hash`(20)),
  UNIQUE KEY `hash_id` (`hash_id`),
  KEY `user_id` (`user_id`),
  KEY `sort_id` (`sort_id`),
  KEY `is_reseed` (`is_reseed`),
  KEY `team_id` (`team_id`),
  KEY `is_commend` (`is_commend`),
  KEY `is_local` (`is_local`),
  KEY `release_date` (`release_date`),
  KEY `upgrade_date` (`upgrade_date`),
  KEY `display` (`put_top`,`upgrade_date`)
) TYPE=MyISAM;
CREATE TABLE `btm_bt_data_ext` (
  `bt_data_id` int(10) unsigned NOT NULL default '0',
  `bt_data_title` varchar(200) NOT NULL default '',
  `bt_data_intro` text NOT NULL,
  `emule_resource` text,
  PRIMARY KEY  (`bt_data_id`)
) TYPE=MyISAM;
CREATE TABLE `btm_config` (
  `name` varchar(50) NOT NULL default '',
  `value` text NOT NULL,
  PRIMARY KEY  (`name`)
) TYPE=MyISAM;
CREATE TABLE `btm_friendly_link` (
  `link_id` int(10) unsigned NOT NULL auto_increment,
  `link_name` varchar(255) NOT NULL default '',
  `link_intro` varchar(255) NOT NULL default '',
  `link_logo` varchar(255) NOT NULL default '',
  `link_url` varchar(255) NOT NULL default '',
  `link_order` int(10) NOT NULL default '0',
  PRIMARY KEY  (`link_id`),
  KEY `link_order` (`link_order`)
) TYPE=MyISAM;
CREATE TABLE `btm_login_node` (
  `node_id` smallint(6) unsigned NOT NULL auto_increment,
  `node_name` varchar(50) NOT NULL default '',
  `node_site_url` varchar(255) NOT NULL default '',
  `node_verify_url` varchar(255) NOT NULL default '',
  `node_encoding` varchar(20) NOT NULL default '',
  `node_key` varchar(50) NOT NULL default '',
  `node_condition` smallint(6) NOT NULL default '0',
  `is_pause` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`node_id`)
) TYPE=MyISAM;
CREATE TABLE `btm_manager` (
  `manager_id` smallint(6) unsigned NOT NULL auto_increment,
  `manager_name` varchar(50) NOT NULL default '',
  `manager_password` varchar(32) NOT NULL default '',
  `dateline` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`manager_id`),
  KEY `manager_name` (`manager_name`)
) TYPE=MyISAM;
CREATE TABLE `btm_manager_log` (
  `log_id` int(10) unsigned NOT NULL auto_increment,
  `manager_id` smallint(6) unsigned NOT NULL default '0',
  `action` text NOT NULL,
  `dateline` int(10) unsigned NOT NULL default '0',
  `client_ip` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`log_id`),
  KEY `dateline` (`dateline`)
) TYPE=MyISAM;
CREATE TABLE `btm_manager_permission` (
  `manager_id` smallint(6) unsigned NOT NULL default '0',
  `can_login` tinyint(1) NOT NULL default '0',
  `is_super_manager` tinyint(1) NOT NULL default '0',
  `can_manage_bt` tinyint(1) NOT NULL default '0',
  `can_manage_sort` tinyint(1) NOT NULL default '0',
  `can_manage_team` tinyint(1) NOT NULL default '0',
  `can_manage_user` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`manager_id`)
) TYPE=MyISAM;
CREATE TABLE `btm_report` (
  `report_id` int(10) unsigned NOT NULL auto_increment,
  `report_url` varchar(250) NOT NULL default '',
  `report_content` text NOT NULL,
  `report_date` int(10) unsigned NOT NULL default '0',
  `report_ip` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`report_id`)
) TYPE=MyISAM;
CREATE TABLE `btm_search_keyword` (
  `search_keyword` varchar(20) NOT NULL default '',
  `search_num` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`search_keyword`),
  KEY `search_num` (`search_num`)
) TYPE=MyISAM;
CREATE TABLE `btm_sort` (
  `sort_id` int(10) unsigned NOT NULL auto_increment,
  `parent_sort_id` int(10) unsigned NOT NULL default '0',
  `sort_name` varchar(50) NOT NULL default '',
  `display_order` int(10) unsigned NOT NULL default '1',
  PRIMARY KEY  (`sort_id`),
  UNIQUE KEY `sort_name` (`sort_name`),
  KEY `parent_sort_id` (`parent_sort_id`),
  KEY `display_order` (`display_order`,`sort_id`)
) TYPE=MyISAM;
CREATE TABLE `btm_team` (
  `team_id` int(10) unsigned NOT NULL auto_increment,
  `team_name` varchar(50) NOT NULL default '',
  `create_user_id` int(10) unsigned NOT NULL default '0',
  `create_date` int(10) unsigned NOT NULL default '0',
  `create_auditing` tinyint(1) NOT NULL default '0',
  `join_condition` enum('close','any','auditing') NOT NULL default 'any',
  `team_display` tinyint(1) NOT NULL default '0',
  `display_order` int(10) unsigned NOT NULL default '0',
  `today_upgrade_num` smallint(6) unsigned NOT NULL default '0',
  `today` varchar(6) NOT NULL default '',
  PRIMARY KEY  (`team_id`),
  UNIQUE KEY `team_name` (`team_name`),
  KEY `create_auditing` (`create_auditing`,`team_display`),
  KEY `create_user_id` (`create_user_id`),
  KEY `display_order` (`display_order`)
) TYPE=MyISAM;
CREATE TABLE `btm_team_user` (
  `team_id` int(10) unsigned NOT NULL default '0',
  `user_id` int(10) unsigned NOT NULL default '0',
  `team_can_edit` tinyint(1) NOT NULL default '0',
  `team_can_delete` tinyint(1) NOT NULL default '0',
  `team_can_upgrade` tinyint(1) NOT NULL default '0',
  `team_can_manage_user` tinyint(1) NOT NULL default '0',
  `join_date` int(10) unsigned NOT NULL default '0',
  `join_auditing` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`team_id`,`user_id`),
  KEY `join_date` (`join_date`)
) TYPE=MyISAM;
CREATE TABLE `btm_user` (
  `user_id` int(10) unsigned NOT NULL auto_increment,
  `user_name` varchar(50) NOT NULL default '',
  `user_password` varchar(32) NOT NULL default '',
  `user_salt` char(8) NOT NULL default '',
  `dateline` int(10) unsigned NOT NULL default '0',
  `team_id` int(10) unsigned NOT NULL default '0',
  `node_id` smallint(6) unsigned NOT NULL default '0',
  `is_auditing` tinyint(1) NOT NULL default '1',
  `can_add` tinyint(1) NOT NULL default '1',
  `can_edit` tinyint(1) NOT NULL default '1',
  `can_delete` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`user_id`),
  KEY `is_auditing` (`is_auditing`),
  KEY `node_id` (`node_id`),
  KEY `team_id` (`team_id`),
  KEY `user_name` (`user_name`)
) TYPE=MyISAM;