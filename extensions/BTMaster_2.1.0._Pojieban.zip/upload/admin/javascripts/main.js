
function $(o){return document.getElementById(o);}
function $F(o){return $(o).value;}
function checkFormData()
{$('submit').value=Lang['submit'];$('submit').disabled=true;return true;}
function cnLength(str)
{if(''==str)return 0;var arr=str.match(/[^\x00-\xff]/ig);return str.length+(arr==null?0:arr.length);}
function selectAll(flag)
{var o=document.getElementsByName('data_id[]');var len=o.length;for(var i=0;i<len;i++)
{o[i].checked=flag;marked_row=new Array;setPointer($('row_'+i),i,(flag?'click':'out'));}}
function againstSelect()
{var o=document.getElementsByName('data_id[]');var len=o.length;for(var i=0;i<len;i++)
{var flag=!o[i].checked;o[i].checked=flag;marked_row=new Array;setPointer($('row_'+i),i,(flag?'click':'out'));}}
function executeOperate()
{var fname=document.form1;var s_type=fname.op.value;if(''==s_type)return false;tag=false;for(var i=0;i<fname.elements.length;i++)
{if('checkbox'==fname.elements[i].type&&fname.elements[i].checked)
{tag=true;break;}}
if(false===tag)
{fname.op.options[0].selected=true;alert(Lang['no_select']);return false;}
if('delete'==s_type)
{if(false==confirm(Lang['delete']))
{fname.op.options[0].selected=true;return false;}}
fname.submit();}
var marked_row=new Array;function setPointer(theRow,theRowNum,theAction)
{var theCells=null;var theMarkClass='highlight';var theDefaultClass="alt1";if((theRowNum+1)%2==0)
{theDefaultClass="alt2";}
if(typeof(theRow.style)=='undefined')
{return false;}
if(typeof(document.getElementsByTagName)!='undefined')
{theCells=theRow.getElementsByTagName('td');}
else if(typeof(theRow.cells)!='undefined')
{theCells=theRow.cells;}
else
{return false;}
var rowCellsCnt=theCells.length;var domDetect=null;var currentClass=null;var newClass=null;if(typeof(window.opera)=='undefined'&&typeof(theCells[0].getAttribute)!='undefined')
{currentClass=theCells[0].className;domDetect=true;}
else
{currentClass=theCells[0].className;domDetect=false;}
if(currentClass==''||currentClass.toLowerCase()==theDefaultClass.toLowerCase())
{if(theAction=='click')
{newClass=theMarkClass;marked_row[theRowNum]=true;}}
else if(typeof(marked_row[theRowNum])=='undefined'||!marked_row[theRowNum])
{if(theAction=='out')
{newClass=theDefaultClass;}
else if(theAction=='click'&&theMarkClass!='')
{newClass=theMarkClass;marked_row[theRowNum]=true;}}
else if(currentClass.toLowerCase()==theMarkClass.toLowerCase())
{if(theAction=='click')
{newClass=theDefaultClass;marked_row[theRowNum]=(typeof(marked_row[theRowNum])=='undefined'||!marked_row[theRowNum])?true:null;}}
var mark_id=$('mark_box_'+theRowNum);if(mark_id)
{if(theMarkClass==newClass)
{mark_id.checked=true;}
else
{mark_id.checked=false;}}
if(newClass)
{var c=null;if(domDetect)
{for(c=0;c<rowCellsCnt;c++)
{theCells[c].className=newClass;}}
else
{for(c=0;c<rowCellsCnt;c++)
{theCells[c].className=newClass;}}}
return true;}