
function checkAll(checked)
{var a=document.getElementsByName('em_data');var n=a.length;for(var i=0;i<n;i++)
{a[i].checked=checked;}
file_size();}
function download(i,first)
{var a=document.getElementsByName('em_data');var n=a.length;for(var i=i;i<n;i++)
{if(a[i].checked)
{window.location=a[i].value;if(first)
{timeout=6000;}
else
{timeout=500;}
i++;window.setTimeout('download('+i+', 0)',timeout);break;}}}
function copy()
{var a=document.getElementsByName('em_data');var n=a.length;var ed2kcopy='';for(var i=0;i<n;i++)
{if(a[i].checked)
{ed2kcopy+=a[i].value;ed2kcopy+="\r\n";}}
copyToClipboard(ed2kcopy);}
function copyToClipboard(txt)
{if(window.clipboardData)
{window.clipboardData.clearData();window.clipboardData.setData('Text',txt);}
else if(navigator.userAgent.indexOf('Opera')!=-1)
{window.location=txt;}
else if(window.netscape)
{try
{netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");}
catch(e)
{alert(Lang['emule_copy_error']);}
var clip=Components.classes['@mozilla.org/widget/clipboard;1'].createInstance(Components.interfaces.nsIClipboard);if(!clip)return;var trans=Components.classes['@mozilla.org/widget/transferable;1'].createInstance(Components.interfaces.nsITransferable);if(!trans)return;trans.addDataFlavor('text/unicode');var str=new Object();var len=new Object();var str=Components.classes["@mozilla.org/supports-string;1"].createInstance(Components.interfaces.nsISupportsString);var copytext=txt;str.data=copytext;trans.setTransferData('text/unicode',str,copytext.length*2);var clipid=Components.interfaces.nsIClipboard;if(!clip)return false;clip.setData(trans,null,clipid.kGlobalClipboard);}}
function file_size()
{var a=document.getElementsByName('em_data');var n=a.length;try
{var input_checkall=$('checkall_em_data');var size=0;input_checkall.checked=true;for(var i=0;i<n;i++)
{if(a[i].checked)
{var piecesArray=a[i].value.split('|');size+=piecesArray[3]*1;}
else
{input_checkall.checked=false;}}
test=$('size_em_data');test.innerHTML=gen_size(size,3,1);}
catch(e)
{alert(e.message);}}
function gen_size(val,li,sepa)
{sep=Math.pow(10,sepa);li=Math.pow(10,li);retval=val;unit='Bytes';if(val>=li*1000000000)
{val=Math.round(val/(1099511627776/sep))/sep;unit='TB';}
else if(val>=li*1000000)
{val=Math.round(val/(1073741824/sep))/sep;unit='GB';}
else if(val>=li*1000)
{val=Math.round(val/(1048576/sep))/sep;unit='MB';}
else if(val>=li)
{val=Math.round(val/(1024/sep))/sep;unit='KB';}
return val+unit;}