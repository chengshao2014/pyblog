
var waitTime=1;var delayTime=0.8;var hideTimer=null;var showTimer=null;var _tmpArray=new Array();var _currentContent=null;$('float_div_content').style.width=floatWindowWidth+'px';$('float_div_content').style.height=floatWindowHeight+'px';waitTime=0>=waitTime?1:waitTime;showTimer=0>=showTimer?1:showTimer;function showContent(event,data_id,hash_id)
{$('float_div').style.display='none';showPosition(event);$('h_'+data_id).onmouseout=hide;showTimer=setTimeout(function(){Tooltip(data_id,hash_id);},1000*waitTime);}
function Tooltip(data_id,hash_id)
{stop();clearTimeout(showTimer);$('float_div_content').innerHTML='';showDiv(data_id,hash_id);if(_tmpArray[data_id])
{_currentContent=_tmpArray[data_id];insertContent(data_id);return true;}
else
{getContent(data_id);}}
function showDiv(data_id,hash_id)
{var show_url='show.php?hash='+hash_id;if(Config['url_rewrite'])
{show_url='show-'+hash_id+'.html';}
$('f_info').innerHTML='[<a href="'+show_url+'" title="'+Lang['info_view']+'">'+Lang['info']+'</a>]&nbsp;[<a href="'+$('h_'+data_id).href+'" title="'+Lang['down_click']+'">'+Lang['down']+'</a>]';$('float_div_title').innerHTML=$('h_'+data_id).innerHTML+'<hr />';$('float_div').style.display='block';$('float_div').style.width=floatWindowWidth+8+'px';$('float_div').onmouseover=stop;$('float_div').onmouseout=hide;}
function insertContent(data_id)
{$('float_div_content').innerHTML=_currentContent;_tmpArray[data_id]=_currentContent;}
function stop()
{if(hideTimer!=null)
{clearTimeout(hideTimer);hideTimer=null;}}
function hide()
{if(hideTimer==null)
{hideTimer=setTimeout(hideTooltip,1000*delayTime);}
if(showTimer!=null)
{clearTimeout(showTimer);}}
function hideTooltip()
{$('float_div').style.display='none';stop();}
function showPosition(event)
{var mouse_x=pointerX(event);var mouse_y=pointerY(event);if(floatWindowHeight+mouse_x>=getWindowWidth())
{mouse_x=mouse_x-floatWindowWidth;}
if(floatWindowHeight+mouse_y>=getWindowHeight())
{mouse_y=mouse_y-floatWindowHeight;}
mouse_x=0>mouse_x?5:mouse_x;mouse_y=0>mouse_y?5:mouse_y;$('float_div').style.left=mouse_x+'px';$('float_div').style.top=mouse_y+'px';}
function getContent(data_id,hash_id)
{var xmlhttp=null;if(window.ActiveXObject)
{try
{xmlhttp=new ActiveXObject("Msxml2.XMLHTTP");}
catch(e)
{try
{xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");}
catch(e){alert(e.message)}}}
else if(window.XMLHttpRequest)
{xmlhttp=new XMLHttpRequest();}
if(null==xmlhttp)
{alert(Lang['ajax_error']);return false;}
_currentContent='<img src="images/loading.gif" />'+Lang['Loading'];insertContent(data_id);var formData="op=content&id="+data_id;xmlhttp.onreadystatechange=prRequest;xmlhttp.open('post','ajax.php',true);xmlhttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded');xmlhttp.send(formData);function prRequest()
{var getState=false;if(xmlhttp.readyState==4)
{if(xmlhttp.status==200)
{getState=true;_currentContent=xmlhttp.responseText;}
if(false==getState)
{_currentContent=Lang['get_error'];}
insertContent(data_id);}}}
function getWindowHeight()
{var innerHeight;if(isIE)
{innerHeight=document.body.clientHeight;}
else
{innerHeight=window.innerHeight;}
return innerHeight;}
function getWindowWidth()
{var innerWidth;if(isIE)
{innerWidth=document.body.clientWidth;}
else
{innerWidth=window.innerWidth;}
return innerWidth;}
function pointerX(event)
{return event.pageX||(event.clientX+(document.documentElement.scrollLeft||document.body.scrollLeft));}
function pointerY(event)
{return event.pageY||(event.clientY+(document.documentElement.scrollTop||document.body.scrollTop));}