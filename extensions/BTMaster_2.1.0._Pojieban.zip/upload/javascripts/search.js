
var valid_bound=new Array('content','hash','team','user','external');function submitFormData()
{var bound=$F('bound');var keyword=$F('keyword');if(''==keyword)
{alert(Lang['keyword_empty']);$('keyword').focus();return false;}
if('external'!=bound)
{var key_length=cnLength(keyword);if(keyword_least>key_length)
{alert(Lang['error_length1']);$('keyword').focus();return false;}
if('content'==bound&&20<key_length)
{alert(Lang['error_length2']);$('keyword').focus();return false;}}
if('hash'==bound)
{if(false==/^[a-z0-9]{40}$/i.test(keyword))
{alert(Lang['error_hash']);$('keyword').focus();return false;}}
if('external'==bound)
{$('search').target='_blank';}
else
{$('search').target='';$('submit').value=Lang['submit'];$('submit').disabled=true;}
return true;}
function switchBound(bound)
{if(undefined==bound||'content'==bound)
{bound='content';$('search_content').style.display='';$('search_external').style.display='none';$('search_user').style.display='none';}
else if('external'==bound)
{$('search_content').style.display='none';$('search_external').style.display='';$('search_user').style.display='none';}
else if('user'==bound)
{$('search_content').style.display='none';$('search_external').style.display='none';$('search_user').style.display='';}
else
{$('search_content').style.display='none';$('search_external').style.display='none';$('search_user').style.display='none';}
var bound_total=valid_bound.length;for(var i=0;i<bound_total;i++)
{if(bound==valid_bound[i])
{$('b_'+valid_bound[i]).className='b_current';}
else
{$('b_'+valid_bound[i]).className='';}}
$('bound').value=bound;$('keyword').focus();}
function syncDisplay()
{$('sync_keyword').innerHTML=$('keyword').value;}
switchBound(location.href.split('#')[1],1);